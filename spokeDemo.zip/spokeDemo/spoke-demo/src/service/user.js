import {
  api,
  getBody,
  USER_ID,
  DEVICE_ID,
  getCarUserID,
  getCarDeviceID,
} from "./api";
import { store } from "../Store";
import { setActiveUsers } from "../Store/users/usersSlice";

const logs = false;

export const updateRealtimeUserData = async (request) => {
  try {
    const { bicycle } = store.getState();
    const { speed, direction, latitude, longitude, index } = bicycle;
    const body = getBody({
      latitude,
      longitude,
      speed,
      direction,
      vehicleType: "cyclist",
    });

    logs && console.log(`${index} Updating ${USER_ID}`);

    const url = `/users/${USER_ID}/devices/${DEVICE_ID}`;
    const { data } = await api.post(url, body);

    return { data, success: true };
  } catch (error) {
    return { success: false };
  }
};

export const updateRealtimeCarData = async ({ carNumber }) => {
  try {
    const userId = getCarUserID(carNumber);
    const deviceId = getCarDeviceID(carNumber);

    const { users } = store.getState();
    const carData = users.cars.find((x) => x.name === getCarUserID(carNumber));

    const { speed, direction, latitude, longitude, index } = carData;
    const body = getBody({ latitude, longitude, speed, direction });

    logs && console.log(`${index} Updating ${userId}`, latitude, longitude);

    const url = `/users/${userId}/devices/${deviceId}`;
    const { data } = await api.post(url, body);

    // store.dispatch(testAction());

    return { data, success: true };
  } catch (error) {
    return { success: false };
  }
};

export const getActiveUsers = async (request) => {
  try {
    const radius = request?.radius || 2000;
    const { bicycle } = store.getState();
    const { latitude, longitude, index } = bicycle;

    logs && console.log(`${index} Getting users`);

    const url = `/users?latitude=${latitude}&longitude=${longitude}&radius=${radius}`;
    const { data } = await api.get(url);

    const newItems = data.item.filter((x) => x.user !== USER_ID);

    store.dispatch(setActiveUsers(newItems));

    return { data: { ...data, item: newItems }, success: true };
  } catch (error) {
    store.dispatch(setActiveUsers([]));
    return { success: false };
  }
};
