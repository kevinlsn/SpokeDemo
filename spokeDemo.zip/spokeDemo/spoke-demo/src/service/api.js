import axios from "axios";
import { nanoid } from "nanoid";

export const api = axios.create({
  baseURL: process.env.REACT_APP_URL,
  headers: {
    "Content-type": "application/json; charset=UTF-8",
  },
});

const ID = nanoid(10);

export const USER_ID = `${ID}-user-bicycle`;
export const DEVICE_ID = `${ID}-device-react`;

export const getCarUserID = (number) => `${ID}-user-car-${number}`;
export const getCarDeviceID = (number) => `${ID}-device-car-${number}`;

// TODO generate unique id for userId and deviceId

export const getBody = ({
  latitude,
  longitude,
  direction,
  speed,
  vehicleType = "driver",
}) => {
  return {
    position_address: "Gran Avenida 22",
    position_latitude: latitude,
    position_longitude: longitude,
    heading_direction: direction,
    is_magnetic_north: false,
    heading_velocity: speed,
    acceleration: 0.3,
    elevation: 0,
    accelerometer_x: 0.1,
    accelerometer_y: 0.1,
    accelerometer_z: 0.1,
    gyro_x: 0.1,
    gyro_y: 0.1,
    gyro_z: 0.1,
    velocity_x: 10,
    velocity_y: 10,
    battery_percent: 69,
    battery_capacity: 4000,
    bicyclists: 3,
    vehicles: 10,
    vehicle_type: vehicleType,
    motion_status: "moving",
    device_type: "smartphone",
  };
};
