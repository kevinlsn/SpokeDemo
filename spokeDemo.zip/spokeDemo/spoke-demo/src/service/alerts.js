import { api, USER_ID, DEVICE_ID } from "./api";
import { store } from "../Store";
import {
  setContextualData,
  setIntersections,
  setProximityWarningsAndAlerts,
} from "../Store/alerts/alertsSlice";

export const getProximityWarningsAndAlerts = async (request) => {
  try {
    const { bicycle } = store.getState();
    const { speed, direction, latitude, longitude } = bicycle;

    const url = `/warnings/users/2227147a-9535-4038-81d9-8c4fa069cbd9/device/${DEVICE_ID}
      /?longitude=${longitude}&latitude=${latitude}&speed=${speed}&direction=${direction}`;

    const { data } = await api.get(url);

    store.dispatch(setProximityWarningsAndAlerts(data.items));

    return { data, success: true };
  } catch (error) {
    return { success: false };
  }
};

export const getInteresections = async () => {
  try {
    const { bicycle } = store.getState();
    const { speed, direction, latitude, longitude } = bicycle;

    const url = `users/${USER_ID}/devices/${DEVICE_ID}/intersections/?longitude=${longitude}&latitude=${latitude}&speed=${speed}&direction=${direction}`;

    const { data } = await api.get(url);

    store.dispatch(setIntersections(data.items));
    // console.log(data.items.right, data.items.left);

    return { data, success: true };
  } catch (error) {
    return { success: false };
  }
};

export const getContextualData = async (request) => {
  try {
    const radius = request?.radius || 2000;
    const { bicycle } = store.getState();
    const { direction, latitude, longitude } = bicycle;

    const url = `users/${USER_ID}/contextual?direction=${direction}
    &radius=${radius}&longitude=${longitude}&latitude=${latitude}`;

    const { data } = await api.get(url);

    store.dispatch(setContextualData(data.items));

    return { data, success: true };
  } catch (error) {
    return { success: false };
  }
};
