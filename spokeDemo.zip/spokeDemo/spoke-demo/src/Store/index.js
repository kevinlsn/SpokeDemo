import { configureStore } from "@reduxjs/toolkit";
import bicycleReducer from "./bicycle/bicycleSlice";
import configReducer from "./config/configSlice";
import usersReducer from "./users/usersSlice";
import alertsReducer from "./alerts/alertsSlice";

export const store = configureStore({
  reducer: {
    bicycle: bicycleReducer,
    config: configReducer,
    users: usersReducer,
    alerts: alertsReducer,
  },
});
