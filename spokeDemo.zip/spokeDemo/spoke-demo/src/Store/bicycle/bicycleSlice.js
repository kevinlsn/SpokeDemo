import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import scriptedData from "../../data/bicycle.json";

const initialState = {
  index: -1,
  speed: scriptedData.places[0].speed,
  direction: scriptedData.places[0].direction,
  latitude: scriptedData.places[0].geometry[0],
  longitude: scriptedData.places[0].geometry[1],
};

// The function below is called a thunk and allows us to perform async logic. It
// can be dispatched like a regular action: `dispatch(incrementAsync(10))`. This
// will call the thunk with the `dispatch` function as the first argument. Async
// code can then be executed and other actions can be dispatched. Thunks are
// typically used to make async requests.
export const incrementAsync = createAsyncThunk(
  "counter/fetchCount",
  async (amount) => {
    // const response = await fetchCount(amount);
    // The value we return becomes the `fulfilled` action payload
    // return response.data;
  }
);

export const bicycleSlice = createSlice({
  name: "bicycle",
  initialState,
  // The `reducers` field lets us define reducers and generate associated actions
  reducers: {
    // Use the PayloadAction type to declare the contents of `action.payload`
    updateBicycleIndex: (state) => {
      const newIndex =
        state.index >= scriptedData.places?.length - 1 ? 0 : state.index + 1;
      state.index = newIndex;

      const lat = scriptedData.places[state.index].geometry[0];
      const lng = scriptedData.places[state.index].geometry[1];
      const speed = scriptedData.places[state.index].speed;
      const direction = scriptedData.places[state.index].direction;

      state.latitude = lat;
      state.longitude = lng;
      state.speed = speed;
      state.direction = direction;
    },
  },
});

export const getBicycleData = (state) => state.bicycle;

export const { updateBicycleIndex } = bicycleSlice.actions;

export default bicycleSlice.reducer;
