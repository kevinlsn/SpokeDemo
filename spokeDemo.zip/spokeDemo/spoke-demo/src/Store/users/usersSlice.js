import { createSlice } from "@reduxjs/toolkit";
import scriptedData from "../../data/cars.json";
import { getCarUserID } from "../../service/api";

const initialState = {
  cars: [],
  activeUsers: [],
};

export const usersSlice = createSlice({
  name: "users",
  initialState,
  reducers: {
    updateCarIndex: (state, action) => {
      const carNumber = action.payload;
      try {
        const arrayPos = state.cars.findIndex(
          (x) => x.name === getCarUserID(carNumber)
        );
        if (arrayPos >= 0) {
          const newIndex =
            state.cars[arrayPos].index >=
            scriptedData[`car${carNumber}`]?.length - 1
              ? 0
              : state.cars[arrayPos].index + 1;

          state.cars[arrayPos].index = newIndex;

          const lat = scriptedData[`car${carNumber}`][newIndex].geometry[0];
          const lng = scriptedData[`car${carNumber}`][newIndex].geometry[1];
          const speed = scriptedData[`car${carNumber}`][newIndex].speed;
          const direction = scriptedData[`car${carNumber}`][newIndex].direction;

          state.cars[arrayPos].latitude = lat;
          state.cars[arrayPos].longitude = lng;
          state.cars[arrayPos].speed = speed;
          state.cars[arrayPos].direction = direction;
          //
        } else {
          const latitude = scriptedData[`car${carNumber}`][0].geometry[0];
          const longitude = scriptedData[`car${carNumber}`][0].geometry[1];
          const speed = scriptedData[`car${carNumber}`][0].speed;
          const direction = scriptedData[`car${carNumber}`][0].direction;

          state.cars.push({
            name: getCarUserID(carNumber),
            latitude,
            longitude,
            speed,
            direction,
            index: 0,
          });
        }
      } catch (error) {}
    },
    setActiveUsers: (state, action) => {
      state.activeUsers = action.payload;
    },
  },
});

export const getActiveUsersSelector = (state) =>
  state?.users?.activeUsers || [];

export const { updateCarIndex, setActiveUsers } = usersSlice.actions;

export default usersSlice.reducer;
