import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  // If want to start paused disable map.onLoad in Initializer.jsx
  isPaused: true,
  follow: true,
};

export const configSlice = createSlice({
  name: "config",
  initialState,
  reducers: {
    startFollowing: (state) => {
      state.follow = true;
    },
    stopFollowing: (state) => {
      state.follow = false;
    },
    pauseSimulation: (state) => {
      state.isPaused = true;
    },
    resumeSimulation: (state) => {
      state.isPaused = false;
    },
  },
});

export const getConfigFollowing = (state) => state.config.follow;
export const getConfigIsPaused = (state) => state.config.isPaused;

export const {
  startFollowing,
  stopFollowing,
  pauseSimulation,
  resumeSimulation,
} = configSlice.actions;

export default configSlice.reducer;
