import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  warningsAndAlerts: [],
  intersections: [],
  contextualData: {},
};

export const alertsSlice = createSlice({
  name: "alerts",
  initialState,
  reducers: {
    setProximityWarningsAndAlerts: (state, action) => {
      state.warningsAndAlerts = action.payload;
    },
    setIntersections: (state, action) => {
      state.intersections = action.payload;
    },
    setContextualData: (state, action) => {
      state.contextualData = action.payload;
    },
  },
});

export const getAlertsReducer = (state) => state.alerts;

export const {
  setProximityWarningsAndAlerts,
  setContextualData,
  setIntersections,
} = alertsSlice.actions;

export default alertsSlice.reducer;
