import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { toast, ToastContainer, Zoom } from "react-toastify";
import { getAlertsReducer } from "../Store/alerts/alertsSlice";
import "react-toastify/dist/ReactToastify.css";

let shownAlerts = [];

const showAlertsAndWarnings = (items) => {
  try {
    const { alerts, warnings } = items;
    alerts.forEach(({ description, risk_level, id }) => {
      if (!shownAlerts.includes(id)) {
        shownAlerts.push(id);
        launchToast({ type: "alert", description });
      }
    });
    warnings.forEach(({ description, risk_level, id }) => {
      if (!shownAlerts.includes(id)) {
        shownAlerts.push(id);
        launchToast({ description });
      }
    });
  } catch (error) {}
};

const showContextual = (items) => {
  try {
    Object.keys(items).forEach((position) => {
      Object.keys(items[position]).forEach((direction) => {
        const vehicles = items[position][direction].total_vehicles;
        if (vehicles > 0) {
          const description = `Warning, ${vehicles} vehicle${
            vehicles > 1 ? "s" : ""
          } ${position} ${direction}`;
          launchToast({ description, position: "top-right", autoClose: 1000 });
        }
      });
    });
  } catch (error) {}
};

const showIntersections = (items) => {
  showAlertsAndWarnings(items.right);
  showAlertsAndWarnings(items.left);
};

const launchToast = ({
  type = "warning",
  description,
  position = "bottom-left",
  autoClose = 2000,
}) => {
  const toastType = type === "alert" ? "error" : "warning";

  toast[toastType](description, {
    position,
    autoClose,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: false,
    draggable: true,
    progress: undefined,
    theme: "dark",
  });
};

const AlertsManager = () => {
  const alerts = useSelector(getAlertsReducer);

  useEffect(() => {
    shownAlerts = [];
  }, []);

  useEffect(() => {
    showAlertsAndWarnings(alerts.warningsAndAlerts);
    showIntersections(alerts.intersections);
    // showContextual(alerts.contextualData);
  }, [alerts]);

  return (
    <ToastContainer
      pauseOnFocusLoss={false}
      pauseOnHover={false}
      transition={Zoom}
    />
  );
};

export default AlertsManager;
