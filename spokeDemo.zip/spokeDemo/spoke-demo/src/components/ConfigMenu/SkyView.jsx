import React, { useContext } from "react";
import planeImage from "../../assets/plane.png";
import { MapContext } from "../MapView";
import { useSelector } from "react-redux";
import { getBicycleData } from "../../Store/bicycle/bicycleSlice";

const SkyView = () => {
  const map = useContext(MapContext);
  const bicycleData = useSelector(getBicycleData);

  const handleClick = () => {
    const { direction } = bicycleData;
    map.setZoom(14);
    // map.setBearing(-direction);
    map.setPitch(0);
  };

  return (
    <button onClick={handleClick}>
      <img alt="Sky view" title="Sky view" src={planeImage} />
    </button>
  );
};

export default SkyView;
