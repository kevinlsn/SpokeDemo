import React, { useState } from "react";
import "./menu.css";
import menuImage from "../../assets/config.png";
import clsoeImage from "../../assets/close.png";
import StopSimulation from "./StopSimulation";
import FollowBicycle from "./FollowBicycle";
import SkyView from "./SkyView";

const ConfigMenu = () => {
  const [displayMenu, setDisplayMenu] = useState(false);

  return (
    <>
      <button
        className="menu-button"
        onClick={() => setDisplayMenu(!displayMenu)}
      >
        <img alt="Menu" title="Open menu" src={menuImage} />
      </button>

      <div
        className="menu-container"
        style={{ display: displayMenu ? "" : "none" }}
      >
        <SkyView />
        <StopSimulation />
        <FollowBicycle />
        <button onClick={() => setDisplayMenu(false)}>
          <img alt="close" title="Close menu" src={clsoeImage} />
        </button>
      </div>
    </>
  );
};

export default ConfigMenu;
