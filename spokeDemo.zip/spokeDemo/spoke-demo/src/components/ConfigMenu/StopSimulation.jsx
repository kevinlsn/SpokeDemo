import React from "react";
import playImage from "../../assets/play2.png";
import pauseImage from "../../assets/pause2.png";
import { useSelector, useDispatch } from "react-redux";
import {
  getConfigIsPaused,
  pauseSimulation,
  resumeSimulation,
} from "../../Store/config/configSlice";

const StopSimulation = () => {
  const dispatch = useDispatch();
  const pausedSimulation = useSelector(getConfigIsPaused);

  return pausedSimulation ? (
    <button onClick={() => dispatch(resumeSimulation())}>
      <img alt="Play" title="Play" src={playImage} />
    </button>
  ) : (
    <button onClick={() => dispatch(pauseSimulation())}>
      <img alt="Pause" title="Pause" src={pauseImage} />
    </button>
  );
};

export default StopSimulation;
