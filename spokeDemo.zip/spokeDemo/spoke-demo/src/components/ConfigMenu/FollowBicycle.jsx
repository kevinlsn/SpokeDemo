import { useContext, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getBicycleData } from "../../Store/bicycle/bicycleSlice";
import {
  getConfigFollowing,
  startFollowing,
  stopFollowing,
} from "../../Store/config/configSlice";
import { MapContext } from "../MapView";
import unfollowImage from "../../assets/unfollow.png";
import followImage from "../../assets/follow.png";

const FollowBicycle = () => {
  const dispatch = useDispatch();
  const map = useContext(MapContext);

  const bicycleData = useSelector(getBicycleData);
  const following = useSelector(getConfigFollowing);

  useEffect(() => {
    map.on("dragstart", () => {
      dispatch(stopFollowing());
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map]);

  const adjustMap = () => {
    const { latitude, longitude, direction } = bicycleData;
    map.setBearing(direction);
    map.panTo([longitude, latitude]);
  };

  useEffect(() => {
    if (following) adjustMap();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bicycleData]);

  return following ? (
    <button onClick={() => dispatch(stopFollowing())}>
      <img alt="Unfollow" title="Unfollow bicycle" src={unfollowImage} />
    </button>
  ) : (
    <button
      onClick={() => {
        dispatch(startFollowing());
        adjustMap();
      }}
    >
      <img alt="Follow" title="Follow bicycle" src={followImage} />
    </button>
  );
};

export default FollowBicycle;
