import React from "react";
import { useSelector } from "react-redux";
import { getActiveUsersSelector } from "../Store/users/usersSlice";
import CarMarker from "./Markers/CarMarker";

const ActiveUsers = () => {
  const users = useSelector(getActiveUsersSelector);

  return (
    <div>
      {users.map((user) => (
        <CarMarker
          key={user.device_name}
          deviceName={user.device_name}
          longitude={user.longitude}
          latitude={user.latitude}
          distance={user.distance}
          direction={user.heading_direction}
          color={
            user?.vehicle_type === "cyclist"
              ? "3"
              : user?.vehicle_type === "driver"
              ? "1"
              : "2"
          }
        />
      ))}
    </div>
  );
};

export default ActiveUsers;
