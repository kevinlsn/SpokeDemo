import React, { useEffect, createContext, useState } from "react";
import "mapbox-gl/dist/mapbox-gl.css";
import mapboxgl from "mapbox-gl";
import Initializer from "./Initializer";
import BicycleMarker from "./Markers/BicycleMarker";
import ActiveUsers from "./ActiveUsers";
import AlertsManager from "./AlertsManager";
import ConfigMenu from "./ConfigMenu";
import Weather from "./Menu/Weather/Weather.jsx";

mapboxgl.accessToken = process.env.REACT_APP_MAPBOX;

export const MapContext = createContext(null);

const MapView = () => {
  const [map, setMap] = useState(null);

  useEffect(() => {
    try {
      const map = new mapboxgl.Map({
        container: "mapbox-container",
        style: "mapbox://styles/mapbox/streets-v11",
        center: [-98.203182, 18.996458],
        zoom: 17,
        pitch: 70, // pitch in degrees
        bearing: 0, // bearing in degree
      });
      map.addControl(new mapboxgl.NavigationControl());
      setMap(map);
    } catch (error) {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <div id="mapbox-container">
        {map && (
          <MapContext.Provider value={map}>
            <ConfigMenu />
            <Initializer />
            <BicycleMarker />
            {/* <Weather /> */}

            <ActiveUsers />
          </MapContext.Provider>
        )}
        <AlertsManager />
      </div>
    </>
  );
};

export default MapView;
