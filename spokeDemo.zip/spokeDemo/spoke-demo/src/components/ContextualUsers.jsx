import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { getAlertsReducer } from "../Store/alerts/alertsSlice";
import CarMarker from "./Markers/CarMarker";

const ContextualUsers = () => {
  const { contextualData } = useSelector(getAlertsReducer);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const cars = [];
    Object.keys(contextualData).forEach((position) => {
      Object.keys(contextualData[position]).forEach((direction) => {
        if (contextualData[position][direction].total_vehicles > 0) {
          contextualData[position][direction].vehicles.forEach((vehicle) => {
            cars.push({
              longitude: vehicle.location.position.longitude,
              latitude: vehicle.location.position.latitude,
              direction: vehicle.location.heading.direction,
              speed: vehicle.location.heading.velocity,
              device_name: vehicle.user_id,
              vehicle_type: vehicle.vehicle_type,
            });
          });
        }
      });
    });
    setUsers(cars);
  }, [contextualData]);

  return (
    <div>
      {users.map((user) => (
        <CarMarker
          key={user.device_name}
          deviceName={user.device_name}
          longitude={user.longitude}
          latitude={user.latitude}
          distance={user.distance}
          direction={user.direction}
          color="2"
        />
      ))}
    </div>
  );
};

export default ContextualUsers;
