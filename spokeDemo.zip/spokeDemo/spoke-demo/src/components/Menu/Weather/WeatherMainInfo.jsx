import Styles from "./weatherMainInfo.module.css";

export default function WeatherMainInfo({ weather }) {
  console.log("weather", weather);

  return (
    <div className={Styles.mainInfo}>
      {weather && (
        <>
          <div className={Styles.city}> {weather?.location.name} </div>
          <div className={Styles.country}> {weather?.location.country} </div>
          <div className={Styles.row}>
            <div>
              <img
                src={`http:${weather.current.condition.icon}`}
                width="60"
                alt={weather?.current.condition.text}
              />

            <div className={Styles.condition}>
              {weather?.current.condition.text}
              <div className={Styles.current}>{weather?.current.temp_c}°</div>
            </div>

            </div>
          </div>


          <div className={Styles.weatherConditions}>
            
          </div>


        </>
      )}
    </div>
  );
}
