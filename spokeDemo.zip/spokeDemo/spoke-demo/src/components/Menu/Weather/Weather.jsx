import { React, useEffect, useState } from "react";
import WeatherForm from "./WeatherForm";
import WeatherMainInfo from "./WeatherMainInfo";

import Styles from "./weatherInfo.module.css";

function WeatherSpeed() {
  const [weather, setWeather] = useState(null);

  useEffect(() => {
    loadInfo();
  }, []);

  /*
    useEffect(() => {
        document.title = `Weather | ${weather?.location.name ?? "" }`
    }, [weather])
    */

  async function loadInfo(city = "puebla") {
    try {
      const request = await fetch(
        `http://api.weatherapi.com/v1/current.json?key=fffd0e88f45d4e0b914145917222508&q=Puebla&aqi=no`
      );

      const json = await request.json();

      setWeather(json);
    } catch (error) {}
  }

  function handleChangeCity(city) {
    setWeather(null);
    loadInfo(city);
  }

  return (
    <div className={Styles.weatherContainer}>
      <div className="container-info">
        <WeatherForm onChangeCity={handleChangeCity} />
        {weather && <WeatherMainInfo weather={weather} />}
      </div>
    </div>
  );
}

export default WeatherSpeed;
