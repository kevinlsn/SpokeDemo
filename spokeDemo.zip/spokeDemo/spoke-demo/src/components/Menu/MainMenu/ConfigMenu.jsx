import React from "react";
import "./ConfigMenu.css";
import Logo from "./logo.svg";
import Equis from "./equis.svg";


function ConfigMenu() {
    return (
        <div className="container">
          <div className="btn-menu">
            <label htmlFor="btn-menu" className="icon-menu">
              <img src={Logo} alt="" />
              {/* <Logo />{" "} */}
            </label>
          </div>
    
          <input type="checkbox" id="btn-menu"></input>
          <div className="container-menu">
            <div className="cont-menu">
              <nav>
                <a href="#">Center</a>
                <a href="#">Cambiar Vista</a>
              </nav>
              <label htmlFor="btn-menu" className="icon-equis">
                {" "}
                {/* <Equis />{" "} */}
              </label>
            </div>
          </div>
        </div>
      );
     }

export default ConfigMenu;
