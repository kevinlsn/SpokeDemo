import { useCallback, useContext, useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux/es/exports";
import carsData from "../data/cars.json";

import { updateBicycleIndex } from "../Store/bicycle/bicycleSlice";
import { updateCarIndex } from "../Store/users/usersSlice";

import {
  getInteresections,
  getProximityWarningsAndAlerts,
} from "../service/alerts";

import {
  getActiveUsers,
  updateRealtimeCarData,
  updateRealtimeUserData,
} from "../service/user";
import {
  getConfigIsPaused,
  resumeSimulation,
} from "../Store/config/configSlice";
import { MapContext } from "./MapView";

const timeInterval = 1000;

const Initializer = () => {
  const dispatch = useDispatch();
  const map = useContext(MapContext);
  const [timer, setTimer] = useState(null);

  const pausedSimulation = useSelector(getConfigIsPaused);

  useEffect(() => {
    if (pausedSimulation) clearInterval(timer);
    else createTimer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pausedSimulation]);

  map.on("load", () => {
    // Comment this line if want to start paused
    if (pausedSimulation) dispatch(resumeSimulation());
  });

  // Handlers

  const updateCarsData = () => {
    const numberOfCars = Object.keys(carsData)?.length;
    for (let index = 0; index < numberOfCars; index++) {
      dispatch(updateCarIndex(index + 1));
      updateRealtimeCarData({ carNumber: index + 1 });
    }
  };

  const getAlerts = () => {
    getProximityWarningsAndAlerts();
    // getContextualData();
    getInteresections();
  };

  const executeServices = () => {
    dispatch(updateBicycleIndex());

    getAlerts();

    updateCarsData();
    updateRealtimeUserData();

    getActiveUsers();
  };

  const createTimer = () => {
    clearInterval(timer);
    executeServices();
    setTimer(
      setInterval(() => {
        executeServices();
      }, timeInterval)
    );
  };

  useEffect(() => {
    return function stopTimer() {
      try {
        clearInterval(timer);
      } catch (error) {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return null;
};

export default Initializer;
