import mapboxgl from "mapbox-gl";
import { useContext, useEffect } from "react";
import { MapContext } from "../MapView";
import "./marker.css";

const CarMarker = ({
  longitude,
  latitude,
  distance,
  direction = 0,
  deviceName,
  color = "1",
}) => {
  let marker = null;
  const map = useContext(MapContext);

  // console.log(deviceName, "coords", latitude, longitude);

  useEffect(() => {
    const el = document.createElement("div");
    el.className = `carMarker-${color}`;

    // eslint-disable-next-line react-hooks/exhaustive-deps
    marker = new mapboxgl.Marker(el);

    marker.setRotationAlignment("map");
    marker.setPitchAlignment("viewport");
    marker.setLngLat([longitude, latitude]);
    marker.setRotation(direction);

    marker.addTo(map);

    return () => {
      marker.remove();
    };
  }, [direction, latitude, longitude, map]);

  return null;
};

export default CarMarker;
