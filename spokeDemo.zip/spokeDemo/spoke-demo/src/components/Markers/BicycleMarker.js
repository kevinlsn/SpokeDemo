import mapboxgl from "mapbox-gl";
import { useContext, useEffect } from "react";
import { useSelector } from "react-redux";
import { getBicycleData } from "../../Store/bicycle/bicycleSlice";
import { MapContext } from "../MapView";
import "./marker.css";

let marker = null;

const BicycleMarker = () => {
  const map = useContext(MapContext);

  const bicycleData = useSelector(getBicycleData);

  useEffect(() => {
    if (marker === null) {
      const el = document.createElement("div");
      el.className = "bicycleMarker";
      marker = new mapboxgl.Marker(el);

      marker.setRotationAlignment("map");
      marker.setPitchAlignment("viewport");
      marker.setLngLat([bicycleData.longitude, bicycleData.latitude]);
      marker.setRotation(bicycleData.direction);

      marker.addTo(map);
    } else {
      const { latitude, longitude, direction } = bicycleData;
      marker.setLngLat([longitude, latitude]);
      marker.setRotation(direction);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map, bicycleData]);

  return null;
};

export default BicycleMarker;
